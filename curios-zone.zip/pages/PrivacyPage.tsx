
import React from 'react';

const PrivacyPage: React.FC = () => {
  return (
    <div className="max-w-4xl mx-auto bg-white p-8 rounded-lg shadow-lg">
      <h1 className="text-4xl font-bold font-playfair text-gray-900 mb-4">Privacy Policy</h1>
      <div className="prose prose-lg max-w-none text-gray-700">
        <p><em>Last updated: October 27, 2023</em></p>

        <p>Curios Zone ("we," "us," or "our") is committed to protecting your privacy. This Privacy Policy explains how we collect, use, and share information about you when you visit our website.</p>

        <h2 className="text-3xl font-playfair font-bold">Information We Collect</h2>
        <p>We may collect information about you in the following ways:</p>
        <ul>
          <li><strong>Google Analytics:</strong> We use Google Analytics to understand how visitors engage with our site. Google Analytics collects information such as how often users visit this site, what pages they visit, and what other sites they used prior to coming to this site. We use this information to improve our website. Google Analytics collects only the IP address assigned to you on the date you visit this site, rather than your name or other identifying information.</li>
          <li><strong>Google AdSense:</strong> We use Google AdSense to display ads on our site. Third-party vendors, including Google, use cookies to serve ads based on a user's prior visits to our website or other websites. Google's use of advertising cookies enables it and its partners to serve ads to our users based on their visit to our sites and/or other sites on the Internet.</li>
        </ul>

        <h2 className="text-3xl font-playfair font-bold">How We Use Information</h2>
        <p>We use the information we collect to:</p>
        <ul>
          <li>Operate and maintain our website;</li>
          <li>Improve, personalize, and expand our website;</li>
          <li>Understand and analyze how you use our website;</li>
          <li>Serve relevant advertisements.</li>
        </ul>
        
        <h2 className="text-3xl font-playfair font-bold">Your Choices</h2>
        <p>You may opt out of personalized advertising by visiting <a href="https://www.google.com/settings/ads" target="_blank" rel="noopener noreferrer">Ads Settings</a>. You can also learn more about Google's privacy practices by visiting their privacy policy.</p>

        <h2 className="text-3xl font-playfair font-bold">Changes to This Policy</h2>
        <p>We may update this Privacy Policy from time to time. We will notify you of any changes by posting the new Privacy Policy on this page.</p>
        
        <h2 className="text-3xl font-playfair font-bold">Contact Us</h2>
        <p>If you have any questions about this Privacy Policy, please contact us at <a href="mailto:privacy@curioszone.com">privacy@curioszone.com</a>.</p>
      </div>
    </div>
  );
};

export default PrivacyPage;


import React from 'react';

const ContactPage: React.FC = () => {
  return (
    <div className="max-w-4xl mx-auto bg-white p-8 rounded-lg shadow-lg">
      <h1 className="text-4xl font-bold font-playfair text-gray-900 mb-4">Contact Us</h1>
      <p className="text-lg text-gray-600 mb-8">
        Have a question, a suggestion for an article, or just want to say hello? We'd love to hear from you.
      </p>

      <div className="grid md:grid-cols-2 gap-8">
        <div>
          <h2 className="text-2xl font-semibold text-gray-800 mb-3">General Inquiries</h2>
          <p className="text-gray-600">
            For general questions and feedback, please email us at:
          </p>
          <a href="mailto:hello@curioszone.com" className="text-indigo-600 font-semibold hover:underline text-lg">
            hello@curioszone.com
          </a>
        </div>
        <div>
           <h2 className="text-2xl font-semibold text-gray-800 mb-3">Future Opportunities</h2>
          <p className="text-gray-600">
            For partnerships, sponsorships, or affiliate inquiries in the future, please use the same email address.
          </p>
          <p className="mt-4 text-sm text-gray-500">
            Please note: Curios Zone is a personal project and response times may vary. Thank you for your understanding.
          </p>
        </div>
      </div>
       {/* Future implementation of a contact form can go here */}
      <div className="mt-12 p-6 bg-gray-50 rounded-lg border border-gray-200">
          <h3 className="text-xl font-semibold text-gray-800 mb-2">Want to write for us?</h3>
          <p className="text-gray-600">
              We are not currently accepting guest posts, but we appreciate your interest! Keep an eye on this page for future opportunities for student writers.
          </p>
      </div>

    </div>
  );
};

export default ContactPage;


import React from 'react';

const TermsPage: React.FC = () => {
  return (
    <div className="max-w-4xl mx-auto bg-white p-8 rounded-lg shadow-lg">
      <h1 className="text-4xl font-bold font-playfair text-gray-900 mb-4">Terms and Conditions</h1>
      <div className="prose prose-lg max-w-none text-gray-700">
        <p><em>Last updated: October 27, 2023</em></p>

        <p>Please read these Terms and Conditions ("Terms", "Terms and Conditions") carefully before using the Curios Zone website (the "Service") operated by us.</p>
        
        <p>Your access to and use of the Service is conditioned on your acceptance of and compliance with these Terms. These Terms apply to all visitors, users, and others who access or use the Service.</p>

        <h2 className="text-3xl font-playfair font-bold">Content</h2>
        <p>All content provided on this blog is for informational purposes only. The owner of this blog makes no representations as to the accuracy or completeness of any information on this site or found by following any link on this site. The owner will not be liable for any errors or omissions in this information nor for the availability of this information.</p>
        
        <h2 className="text-3xl font-playfair font-bold">User Conduct</h2>
        <p>You agree not to use the website in a way that:</p>
        <ul>
          <li>Is unlawful, harmful, or fraudulent.</li>
          <li>Attempts to click on advertisements on your own behalf or encourage others to do so.</li>
          <li>Infringes upon the intellectual property rights of others.</li>
        </ul>
        
        <h2 className="text-3xl font-playfair font-bold">Advertisements</h2>
        <p>This website is monetized through Google AdSense. By using this website, you agree to the presence of advertisements. We are not responsible for the content of these advertisements or the products/services they promote.</p>
        
        <h2 className="text-3xl font-playfair font-bold">Links To Other Web Sites</h2>
        <p>Our Service may contain links to third-party web sites or services that are not owned or controlled by Curios Zone. We have no control over, and assume no responsibility for, the content, privacy policies, or practices of any third party web sites or services.</p>
        
        <h2 className="text-3xl font-playfair font-bold">Changes</h2>
        <p>We reserve the right, at our sole discretion, to modify or replace these Terms at any time. We will try to provide at least 30 days' notice prior to any new terms taking effect. What constitutes a material change will be determined at our sole discretion.</p>
        
        <h2 className="text-3xl font-playfair font-bold">Contact Us</h2>
        <p>If you have any questions about these Terms, please contact us.</p>
      </div>
    </div>
  );
};

export default TermsPage;

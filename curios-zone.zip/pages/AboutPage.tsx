import React from 'react';
import { Link } from 'react-router-dom';

const AboutPage: React.FC = () => {
  return (
    <div className="max-w-4xl mx-auto bg-white p-8 rounded-lg shadow-lg">
      <h1 className="text-4xl font-bold font-playfair text-gray-900 mb-4">About Curios Zone</h1>
      <p className="text-lg text-gray-600 mb-6">
        Curios Zone is a modern, student-friendly online magazine designed to share knowledge, facts, and ideas in a fun and readable way. It's a platform built by a student to inspire curiosity in young minds.
      </p>

      <div className="prose prose-lg max-w-none text-gray-700">
        <h2 className="text-3xl font-playfair font-bold">Project Goals</h2>
        <ul>
          <li>Create a functional and visually appealing blog website.</li>
          <li>Share original educational content across science, tech, history, and curiosity topics.</li>
          <li>Integrate Google Analytics for visitor tracking and Google AdSense for monetization.</li>
          <li>Apply real-world digital skills like coding, writing, SEO, design, and analytics.</li>
        </ul>

        <h2 className="text-3xl font-playfair font-bold mt-8">The Founder</h2>
        <div className="bg-gray-50 p-6 rounded-lg">
          <div>
            <h3 className="text-2xl font-semibold">Mohammed Yaseen</h3>
            <p className="text-gray-600">Age: 12</p>
            <p className="italic mt-2">"I created Curios Zone to share my love for learning and to show that anyone, no matter their age, can build something amazing with code and creativity."</p>
          </div>
        </div>

        <p className="mt-8">
          Thank you for visiting! We hope you enjoy exploring the amazing facts and stories we have to share. If you have any questions, feel free to reach out via our <Link to="/contact" className="text-indigo-600 hover:underline">Contact Page</Link>.
        </p>
      </div>
    </div>
  );
};

export default AboutPage;


import React from 'react';
import { useParams, Link } from 'react-router-dom';
import { posts } from '../data/posts';
import NotFoundPage from './NotFoundPage';

const PostPage: React.FC = () => {
  const { slug } = useParams<{ slug: string }>();
  const post = posts.find(p => p.slug === slug);

  if (!post) {
    return <NotFoundPage />;
  }

  const categoryColors: { [key: string]: string } = {
    Science: 'bg-blue-100 text-blue-800',
    Tech: 'bg-green-100 text-green-800',
    History: 'bg-yellow-100 text-yellow-800',
    Curiosity: 'bg-purple-100 text-purple-800',
  };
  const categoryClass = categoryColors[post.category] || 'bg-gray-100 text-gray-800';


  return (
    <article className="max-w-4xl mx-auto bg-white p-6 sm:p-8 lg:p-12 rounded-lg shadow-xl">
      <header className="mb-8 border-b pb-6">
        <div className="flex justify-between items-center mb-4">
             <span className={`px-3 py-1 text-sm font-semibold rounded-full ${categoryClass}`}>
                {post.category}
            </span>
            <Link to="/" className="text-indigo-600 hover:underline text-sm font-semibold">&larr; Back to all articles</Link>
        </div>
        <h1 className="text-4xl md:text-5xl font-extrabold font-playfair text-gray-900 leading-tight mb-4">{post.title}</h1>
        <div className="text-md text-gray-500">
          <span>By {post.author}</span> &middot; <span>{post.date}</span>
        </div>
      </header>
      
      <img src={post.imageUrl} alt={post.title} className="w-full h-auto max-h-96 object-cover rounded-lg mb-8 shadow-md" />
      
      {/* Placeholder for AdSense Article Ad */}
      <div className="my-8 h-48 bg-gray-200 flex items-center justify-center text-gray-500 rounded-md">
        [AdSense In-article Ad Placeholder]
      </div>

      <div 
        className="prose prose-lg max-w-none text-gray-700 leading-relaxed"
        dangerouslySetInnerHTML={{ __html: post.content }}
      />
    </article>
  );
};

export default PostPage;

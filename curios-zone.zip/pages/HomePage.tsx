import React, { useState } from 'react';
import { posts } from '../data/posts';
import PostCard from '../components/PostCard';
import DailyFact from '../components/DailyFact';

const HomePage: React.FC = () => {
  const [searchTerm, setSearchTerm] = useState('');
  
  const filteredPosts = posts.filter(post =>
    post.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
    post.summary.toLowerCase().includes(searchTerm.toLowerCase()) ||
    post.category.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <div>
      <header className="text-center py-12 bg-white rounded-lg shadow-md mb-10">
        <h1 className="text-5xl font-extrabold font-playfair text-gray-900 leading-tight">
          Welcome to <span className="text-indigo-600">Curios Zone</span>
        </h1>
        <p className="mt-4 text-lg text-gray-600 max-w-2xl mx-auto">
          A modern magazine for curious minds. Discover fascinating facts, ideas, and stories from the worlds of science, tech, and history.
        </p>
      </header>

      {/* Placeholder for AdSense Leaderboard Ad */}
      <div className="my-8 h-24 bg-gray-200 flex items-center justify-center text-gray-500 rounded-md">
        [AdSense Leaderboard Ad Placeholder]
      </div>

      <DailyFact />

      <div className="mb-8">
        <input
          type="text"
          placeholder="Search for articles..."
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
          className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 transition-shadow"
          aria-label="Search articles"
        />
      </div>

      <div className="grid gap-8 md:grid-cols-2 lg:grid-cols-3">
        {filteredPosts.length > 0 ? (
          filteredPosts.map(post => <PostCard key={post.slug} post={post} />)
        ) : (
          <div className="md:col-span-2 lg:col-span-3 text-center py-12">
            <p className="text-xl text-gray-500">No articles found matching your search.</p>
          </div>
        )}
      </div>

      {/* Placeholder for in-feed AdSense Ad */}
      {filteredPosts.length > 3 && (
        <div className="my-8 h-48 bg-gray-200 flex items-center justify-center text-gray-500 rounded-md md:col-span-2 lg:col-span-3">
            [AdSense In-feed Ad Placeholder]
        </div>
      )}

    </div>
  );
};

export default HomePage;

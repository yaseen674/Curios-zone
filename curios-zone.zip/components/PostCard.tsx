
import React from 'react';
import { Link } from 'react-router-dom';
import { Post } from '../types';

interface PostCardProps {
  post: Post;
}

const categoryColors: { [key: string]: string } = {
  Science: 'bg-blue-100 text-blue-800',
  Tech: 'bg-green-100 text-green-800',
  History: 'bg-yellow-100 text-yellow-800',
  Curiosity: 'bg-purple-100 text-purple-800',
};

const PostCard: React.FC<PostCardProps> = ({ post }) => {
  const categoryClass = categoryColors[post.category] || 'bg-gray-100 text-gray-800';
  
  return (
    <Link to={`/post/${post.slug}`} className="group block overflow-hidden rounded-lg shadow-lg hover:shadow-2xl transition-shadow duration-300 bg-white">
      <div className="relative">
        <img src={post.imageUrl} alt={post.title} className="w-full h-48 object-cover group-hover:scale-105 transition-transform duration-300" />
        <div className={`absolute top-4 right-4 px-3 py-1 text-xs font-semibold rounded-full ${categoryClass}`}>
          {post.category}
        </div>
      </div>
      <div className="p-6">
        <h3 className="text-xl font-bold font-playfair mb-2 text-gray-900 group-hover:text-indigo-600 transition-colors duration-300">{post.title}</h3>
        <p className="text-gray-600 text-sm mb-4 line-clamp-2">{post.summary}</p>
        <div className="text-xs text-gray-500">
          <span>By {post.author}</span> &middot; <span>{post.date}</span>
        </div>
      </div>
    </Link>
  );
};

export default PostCard;

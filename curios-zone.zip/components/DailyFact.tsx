
import React, { useState, useEffect } from 'react';
import { getDailyFact } from '../services/geminiService';
import { SparklesIcon, RefreshIcon } from './IconComponents';

const DailyFact: React.FC = () => {
  const [fact, setFact] = useState<string>('');
  const [loading, setLoading] = useState<boolean>(true);

  const fetchFact = () => {
    setLoading(true);
    getDailyFact()
      .then(setFact)
      .finally(() => setLoading(false));
  };

  useEffect(() => {
    fetchFact();
  }, []);

  return (
    <div className="bg-gradient-to-r from-indigo-500 to-purple-600 rounded-lg p-6 my-10 text-white shadow-xl">
      <div className="flex items-center mb-4">
        <SparklesIcon />
        <h3 className="text-2xl font-bold font-playfair ml-3">Daily Curiosity Fact</h3>
      </div>
      <div className="relative min-h-[6rem]">
        {loading ? (
          <div className="absolute inset-0 flex items-center justify-center">
             <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-white"></div>
          </div>
        ) : (
          <p className="text-lg opacity-90">{fact}</p>
        )}
      </div>
      <div className="text-right mt-4">
        <button
          onClick={fetchFact}
          disabled={loading}
          className="inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md shadow-sm text-indigo-700 bg-white hover:bg-indigo-50 disabled:bg-gray-300 disabled:cursor-not-allowed transition-colors"
        >
          <RefreshIcon loading={loading} />
          New Fact
        </button>
      </div>
    </div>
  );
};

export default DailyFact;


import { GoogleGenAI } from "@google/genai";

const API_KEY = process.env.API_KEY;

if (!API_KEY) {
  console.warn("API_KEY environment variable not set. AI features will be disabled.");
}

const ai = new GoogleGenAI({ apiKey: API_KEY! });

export const getDailyFact = async (): Promise<string> => {
  if (!API_KEY) {
    return "AI features are currently disabled. API key is missing.";
  }
  
  try {
    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: "Tell me a single, fascinating, and verifiable fun fact suitable for a student's curiosity blog. Make it short, one or two sentences at most. Ensure it is easily understandable for a 12-year-old.",
    });
    
    return response.text.trim();
  } catch (error) {
    console.error("Error fetching daily fact from Gemini:", error);
    return "Could not fetch a fact at this moment. Please try again later.";
  }
};

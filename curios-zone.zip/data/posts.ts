
import { Post } from '../types';

export const posts: Post[] = [
  {
    slug: 'the-secrets-of-black-holes',
    title: 'The Secrets of Black Holes: Natures Ultimate Mystery',
    author: 'Mohammed Yaseen',
    date: 'October 26, 2023',
    summary: 'Dive deep into the enigmatic world of black holes, where the laws of physics as we know them break down.',
    content: `
      <p class="mb-4">Black holes are one of the most fascinating objects in the universe. They are regions of spacetime where gravity is so strong that nothing—no particles or even electromagnetic radiation such as light—can escape from it. The theory of general relativity predicts that a sufficiently compact mass can deform spacetime to form a black hole.</p>
      <p class="mb-4">The boundary of the region from which no escape is possible is called the event horizon. Although the event horizon has an enormous effect on the fate and circumstances of an object crossing it, no locally detectable features appear to be observed. In many ways, a black hole acts like an ideal black body, as it reflects no light.</p>
      <h3 class="text-2xl font-bold mt-6 mb-3 font-playfair">How Are They Formed?</h3>
      <p class="mb-4">Stellar-mass black holes are expected to form when very massive stars collapse at the end of their life cycle. After a black hole has formed, it can continue to grow by absorbing mass from its surroundings. By absorbing other stars and merging with other black holes, supermassive black holes of millions of solar masses may form. There is general consensus that supermassive black holes exist in the centers of most galaxies.</p>
    `,
    imageUrl: 'https://picsum.photos/seed/blackhole/800/600',
    category: 'Science',
  },
  {
    slug: 'ai-friend-or-foe',
    title: 'Artificial Intelligence: A Students Best Friend or Future Foe?',
    author: 'Mohammed Yaseen',
    date: 'October 24, 2023',
    summary: 'Exploring how AI is changing the world of education and what it means for students today and tomorrow.',
    content: `
      <p class="mb-4">Artificial Intelligence (AI) is no longer a concept from science fiction; it's a part of our daily lives. For students, AI tools can act as powerful assistants, helping with research, writing, and even complex problem-solving. Apps like Grammarly use AI to improve our writing, while others can help us learn new languages or master difficult math concepts.</p>
      <p class="mb-4">However, with great power comes great responsibility. The rise of AI also raises questions about originality, cheating, and the future of jobs. Is it okay to use an AI to write your essay? What skills should we focus on when AI can automate so many tasks? This article explores both sides of the coin, offering a balanced view on how to use AI ethically and effectively in your learning journey.</p>
    `,
    imageUrl: 'https://picsum.photos/seed/ai/800/600',
    category: 'Tech',
  },
  {
    slug: 'ancient-roman-inventions',
    title: 'Inventions of Ancient Rome That We Still Use Today',
    author: 'Mohammed Yaseen',
    date: 'October 22, 2023',
    summary: 'Journey back in time to discover the incredible engineering and innovations of the Roman Empire that shaped our modern world.',
    content: `
      <p class="mb-4">The Roman Empire, which lasted for over 1,000 years, was a powerhouse of innovation. Many of their inventions were so advanced that they continue to influence our lives today. The most famous are perhaps their roads and aqueducts. Roman roads, built with layers of stone and gravel, created a network that connected their vast empire, and many modern highways in Europe follow their original paths.</p>
      <p class="mb-4">Aqueducts were marvels of civil engineering, using gravity to transport water over long distances to supply cities with fresh water for drinking, bathing, and sanitation. They also gave us concrete, Julian calendar, newspapers (Acta Diurna), and even the concept of apartment buildings (insulae). Understanding these inventions gives us a newfound appreciation for the ingenuity of the ancient world.</p>
    `,
    imageUrl: 'https://picsum.photos/seed/rome/800/600',
    category: 'History',
  },
  {
    slug: 'the-amazing-world-of-ants',
    title: 'The Amazing World of Ants: Tiny Creatures, Giant Impact',
    author: 'Mohammed Yaseen',
    date: 'October 20, 2023',
    summary: 'Did you know that the total weight of all ants on Earth is roughly equal to the total weight of all humans? Let\'s explore their world!',
    content: `
      <p class="mb-4">Ants are some of the most successful creatures on the planet. They have colonized almost every landmass on Earth. Their success lies in their social organization and ability to modify habitats, tap resources, and defend themselves. These tiny insects live in highly organized colonies that can consist of millions of individuals.</p>
      <p class="mb-4">Each ant has a specific job, from the queen who lays the eggs, to the workers who gather food and build the nest, to the soldiers who defend the colony. They communicate using chemical signals called pheromones, leaving trails that others can follow to food sources. Studying ants can teach us a lot about teamwork, communication, and efficiency.</p>
    `,
    imageUrl: 'https://picsum.photos/seed/ants/800/600',
    category: 'Curiosity',
  },
  {
    slug: 'why-is-the-sky-blue',
    title: 'A Simple Answer to a Classic Question: Why is the Sky Blue?',
    author: 'Mohammed Yaseen',
    date: 'October 18, 2023',
    summary: 'Unraveling the science behind the blue hue of our sky in a way that is easy for everyone to understand.',
    content: `
      <p class="mb-4">It’s a question every child asks, and the answer is all about light and our atmosphere. Sunlight may look white, but it's actually made up of all the colors of the rainbow. When this light travels from the sun to the Earth, it passes through the atmosphere, which is filled with tiny gas molecules.</p>
      <p class="mb-4">Light travels in waves, and different colors have different wavelengths. Blue light has shorter, smaller waves, while red light has longer, stretched-out waves. The gas molecules in the air are just the right size to scatter the shorter wavelengths of light, like blue and violet. So, as sunlight enters our atmosphere, the blue light gets scattered in all directions, making the sky appear blue to our eyes. At sunset, the sun is lower in the sky, and its light has to pass through more atmosphere, scattering away the blue light and leaving the reds and oranges for us to see.</p>
    `,
    imageUrl: 'https://picsum.photos/seed/sky/800/600',
    category: 'Science',
  },
  {
    slug: 'the-power-of-coding',
    title: 'The Power of Coding: How Learning to Code Can Be Your Superpower',
    author: 'Mohammed Yaseen',
    date: 'October 15, 2023',
    summary: 'From building websites to creating games, coding is a skill that opens up a world of creativity and problem-solving.',
    content: `
      <p class="mb-4">Learning to code is like learning a new language, but instead of talking to people, you're talking to computers. It's the skill of giving instructions to a computer to make it do what you want. This could be anything from designing a website like Curios Zone, to building a fun mobile game, or even programming a robot.</p>
      <p class="mb-4">Coding teaches you how to think logically and break down big problems into smaller, manageable steps. It's a creative outlet that allows you to bring your ideas to life. With languages like Python, JavaScript, and HTML/CSS, you can start building amazing things right from your computer. The best part? There are tons of free resources online to help you get started on your coding journey!</p>
    `,
    imageUrl: 'https://picsum.photos/seed/coding/800/600',
    category: 'Tech',
  }
];
